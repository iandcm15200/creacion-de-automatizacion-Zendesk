# WhatsApp UDLA Retención - App Final

## 🎯 Decisión Técnica (Senior Level)

Esta app usa la **estructura REAL de CXConnect** validada en tu documentación:
- ✅ producto_id: 1156221
- ✅ nombre_plantilla: 2566_m_intentocontacto_na_plantillasasesores
- ✅ subdominio: aplatam4961
- ✅ Estructura de JSON completa del documento

**Por qué esta decisión:**
1. Usa valores REALES probados (no adivinados)
2. Alineada con tu script Tampermonkey existente
3. Basada en cURL funcional validado
4. Funciona desde día 1

---

## 🚀 Instalación Rápida

### 1. Empaquetar
```bash
cd whatsapp-udla-final
zat validate
zat package
```

### 2. Subir a Zendesk
- Admin Center > Apps > Upload private app
- Selecciona el .zip de `tmp/`

### 3. Configurar (valores YA correctos)
```
Título: WhatsApp UDLA Retención

URL API: https://cxconnectav-aol.cxclatam.com/api/v2/play-one-to-one-proactive

subdominio: aplatam4961
producto_id: 1156221
nombre_plantilla: 2566_m_intentocontacto_na_plantillasasesores
target_tag: no_contesto_whatsapp

enable_auto_send: ☑️ Marcado
```

---

## 📱 ¿Cómo Funciona?

### Flujo Completo:

```
1. Agente presiona Shift+7 (o click manual en Macro 007)
    ↓
2. Macro agrega etiqueta: no_contesto_whatsapp
    ↓
3. App detecta cambio automáticamente
    ↓
4. Valida:
   ✓ Etiqueta correcta
   ✓ Teléfono existe
   ✓ País soportado (MX/EC/CR)
    ↓
5. Normaliza teléfono según país
   - México: +52 + 10 dígitos
   - Ecuador: +593 + 9 dígitos
   - Costa Rica: +506 + 8 dígitos
    ↓
6. Envía a CXConnect con estructura del documento:
   {
     subdominio: "aplatam4961",
     producto_id: "1156221",
     telefono: "525512345678",
     nombre_plantilla: "2566_m_intentocontacto_na_plantillasasesores",
     plantilla: { JSON complejo }
   }
    ↓
7. Registra en historial
   📝 Comentario interno en ticket
   💾 localStorage del ticket
```

---

## 🌎 Países Soportados

| País | Código | Longitud | Ejemplo |
|------|--------|----------|---------|
| 🇲🇽 México | +52 | 10 dígitos | +525512345678 |
| 🇪🇨 Ecuador | +593 | 9 dígitos | +593999123456 |
| 🇨🇷 Costa Rica | +506 | 8 dígitos | +50672029919 |

**Normalización automática:**
- `999 123 456` (9 dígitos) → `593999123456` (Ecuador)
- `7202 9919` (8 dígitos) → `50672029919` (Costa Rica)
- `55 1234 5678` (10 dígitos) → `525512345678` (México)

---

## 🎨 Interfaz

La app muestra en el sidebar:

### Información del Ticket:
- 📱 **Teléfono:** Con bandera del país detectado
- 🌎 **País:** Nombre completo
- 📊 **Estado:** Del ticket

### Validaciones en Tiempo Real:
- ✓ Etiqueta: no_contesto_whatsapp
- ✓ Teléfono válido
- ✓ País soportado (MX/EC/CR)

### Indicador Automático:
- 🤖 "Esperando condiciones..." (cuando falta algo)
- ✓ "Listo para enviar" (cuando todo está bien)

### Historial:
- Últimos 5 mensajes
- Con fecha, tipo (auto/manual), estado

### Botón Manual:
- Solo activo cuando pasan todas las validaciones

---

## 🔧 Configuración Técnica

### Estructura de Request a CXConnect:

```javascript
POST https://cxconnectav-aol.cxclatam.com/api/v2/play-one-to-one-proactive

Content-Type: application/x-www-form-urlencoded

Body:
subdominio=aplatam4961
plantilla={"destination":{"integrationId":"--integrationId--","destinationId":"525512345678"},"author":{"role":"appMaker"},"messageSchema":"whatsapp","message":{"type":"template","template":{"namespace":"--namespace--","name":"2566_m_intentocontacto_na_plantillasasesores","language":{"policy":"deterministic","code":"es"}}}}
producto_id=1156221
telefono=525512345678
nombre_plantilla=2566_m_intentocontacto_na_plantillasasesores
```

**Placeholders automáticos:**
- `--integrationId--` → Reemplazado por servidor CXConnect
- `--namespace--` → Reemplazado por servidor CXConnect

---

## 🧪 Testing

### Prueba 1: Envío Manual

1. Crea ticket de prueba
2. Agrega teléfono al requester:
   - México: `+52 55 1234 5678`
   - Ecuador: `+593 999 123 456`
   - Costa Rica: `+506 7202 9919`
3. Abre el ticket
4. Agrega etiqueta manualmente: `no_contesto_whatsapp`
5. Ve al sidebar - las 3 validaciones deben estar en verde ✓✓✓
6. Click "Enviar ahora"

**Resultado:** Mensaje enviado y aparece en historial

### Prueba 2: Con Macro 007

1. Ticket con teléfono válido
2. Presiona `Shift+7`
3. Macro se aplica
4. App detecta y envía automáticamente
5. Verifica historial

**Resultado:** Envío automático exitoso

---

## 📊 Logs

Cada envío se registra como comentario interno:

```
[WhatsApp UDLA] Automático
📱 Teléfono: +525512345678
🌎 País: México
✅ Estado: success
🕐 05/12/2025 14:30:45
```

---

## 🐛 Troubleshooting

### No se envía automáticamente

**Revisa:**
1. ¿La etiqueta es exactamente `no_contesto_whatsapp`?
2. ¿El teléfono tiene el formato correcto?
3. ¿Las 3 validaciones están en verde?
4. ¿`enable_auto_send` está marcado?

**Debug:**
- Abre consola (F12)
- Busca: `🟢 WhatsApp UDLA iniciada`
- Revisa logs de validación

### País no soportado

**Causa:** Número no es de México, Ecuador o Costa Rica

**Solución:** Esta app solo funciona con esos 3 países

### Error al enviar

**Causas comunes:**
1. CXConnect no responde
2. Formato de teléfono incorrecto
3. producto_id o nombre_plantilla incorrectos

**Verificación con cURL:**
```bash
curl -X POST "https://cxconnectav-aol.cxclatam.com/api/v2/play-one-to-one-proactive" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "subdominio=aplatam4961" \
  -d "producto_id=1156221" \
  -d "telefono=525512345678" \
  -d "nombre_plantilla=2566_m_intentocontacto_na_plantillasasesores" \
  -d 'plantilla={"destination":{"integrationId":"--integrationId--","destinationId":"525512345678"},"author":{"role":"appMaker"},"messageSchema":"whatsapp","message":{"type":"template","template":{"namespace":"--namespace--","name":"2566_m_intentocontacto_na_plantillasasesores","language":{"policy":"deterministic","code":"es"}}}}'
```

---

## 💡 Ventajas vs Tampermonkey

| Aspecto | Tampermonkey | App Nativa |
|---------|--------------|------------|
| **Instalación** | Cada navegador | Una vez en Zendesk |
| **Visibilidad** | Console logs | UI en sidebar |
| **Historial** | No | Sí, últimos 5 |
| **Debugging** | Manual | Visual en tiempo real |
| **Mantenimiento** | Cada usuario | Centralizado |
| **Fiabilidad** | Depende del script | Nativo de Zendesk |

---

## 🔐 Seguridad

- ✅ No guarda datos sensibles
- ✅ Solo se conecta a CXConnect (tu API)
- ✅ Comentarios internos (no visibles al cliente)
- ✅ localStorage solo para historial del ticket

---

## 📚 Estructura del Código

```
whatsapp-udla-final/
├── manifest.json          # Configuración con valores reales
├── assets/
│   ├── iframe.html       # UI simple y clara
│   ├── main.css          # Estilos profesionales
│   └── main.js           # Lógica con estructura del documento
├── translations/
│   └── es.json
└── README.md             # Esta documentación
```

---

## 🚀 Próximos Pasos

### Después de probar UDLA:

1. ✅ Validar mensajes llegan correctamente
2. ✅ Confirmar logs en CXConnect
3. ✅ Capacitar agentes
4. 🔜 Crear versión para UDEM
5. 🔜 Crear versión para ULatina
6. 🔜 Unificar en app multi-institución

---

## 📞 Soporte

**Email:** soporte@aplatam.com  
**Equipo:** APLATAM

---

## ✅ Checklist de Implementación

- [ ] ZAT instalado
- [ ] App empaquetada
- [ ] App subida a Zendesk
- [ ] Parámetros configurados (valores YA correctos)
- [ ] App activada
- [ ] Prueba manual exitosa
- [ ] Prueba con Macro 007 exitosa
- [ ] Agentes capacitados

---

**Versión:** 1.0.0  
**Fecha:** Diciembre 2025  
**Autor:** APLATAM

**🎯 Esta app usa valores REALES de tu documentación - Funciona desde día 1**
