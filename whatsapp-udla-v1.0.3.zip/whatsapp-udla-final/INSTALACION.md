# 🚀 Instalación en 3 Pasos

## Paso 1: Empaquetar (solo si tienes ZAT)

```bash
cd whatsapp-udla-final
zat validate
zat package
```

El archivo quedará en: `tmp/app-XXXXX.zip`

---

## Paso 2: Subir a Zendesk

1. Ve a: `https://aplatam4961.zendesk.com/admin/apps-integrations/apps/support-apps`
2. Click: **"Upload private app"**
3. Selecciona el archivo `.zip`

---

## Paso 3: Configurar

**Los valores YA están correctos por defecto:**

```
✅ URL API: https://cxconnectav-aol.cxclatam.com/api/v2/play-one-to-one-proactive
✅ subdominio: aplatam4961
✅ producto_id: 1156221
✅ nombre_plantilla: 2566_m_intentocontacto_na_plantillasasesores
✅ target_tag: no_contesto_whatsapp
✅ enable_auto_send: Marcado
```

**Solo necesitas:**
- Poner un título: `WhatsApp UDLA`
- Click "Instalar"

---

## ✅ Verificar

1. Abre cualquier ticket
2. Busca en el sidebar derecho
3. Deberías ver: **"📱 WhatsApp UDLA"**

---

## 🧪 Primera Prueba

1. Crea ticket con teléfono: `+52 55 1234 5678`
2. Agrega etiqueta: `no_contesto_whatsapp`
3. Ve al sidebar - las 3 validaciones deben estar en verde ✓
4. Click "✉️ Enviar ahora"

---

## 🤖 Con Macro 007

1. Ticket con teléfono válido
2. Presiona `Shift+7` (o click manual)
3. ¡Envío automático!

---

**⏱️ Tiempo total: 10 minutos**

**✅ Funciona desde día 1** - Usa valores reales de tu documentación
