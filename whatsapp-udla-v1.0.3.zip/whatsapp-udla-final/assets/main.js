/* WhatsApp UDLA - Estructura Real de CXConnect */

(function() {
  'use strict';

  let client = null;
  let settings = {};
  let ticketData = {};
  let validation = { tag: false, phone: false, country: false };

  // Países soportados
  const COUNTRIES = {
    '52': { name: 'México', flag: '🇲🇽', code: 'MX' },
    '593': { name: 'Ecuador', flag: '🇪🇨', code: 'EC' },
    '506': { name: 'Costa Rica', flag: '🇨🇷', code: 'CR' }
  };

  console.log('🟢 WhatsApp UDLA iniciando...');
  
  // ==================== INICIALIZACIÓN ZAF ====================
  
  function initZAF() {
    return new Promise((resolve, reject) => {
      let attempts = 0;
      const maxAttempts = 40; // 40 × 500ms = 20 segundos
      
      const interval = setInterval(() => {
        attempts++;
        
        if (typeof ZAFClient !== 'undefined') {
          clearInterval(interval);
          client = ZAFClient.init();
          console.log('[ZAF] ✓ Cliente inicializado');
          resolve(client);
        } else if (attempts >= maxAttempts) {
          clearInterval(interval);
          console.error('[ZAF] ✗ Timeout después de 20 segundos');
          reject(new Error('ZAF no disponible'));
        } else {
          console.log(`[ZAF] Intento ${attempts}/${maxAttempts}...`);
        }
      }, 500);
    });
  }
  
  // Inicializar la app
  async function initialize() {
    try {
      // Esperar a que ZAF esté disponible
      await initZAF();
      
      client.invoke('resize', { width: '100%', height: '700px' });
      
      // Obtener datos
      const [metadata, ticketResponse, requesterResponse] = await Promise.all([
        client.metadata(),
        client.get('ticket'),
        client.get('ticket.requester')
      ]);
      
      settings = metadata.settings;
      ticketData = ticketResponse.ticket;
      ticketData.requester = requesterResponse['ticket.requester'];
      
      console.log('⚙️ Configuración:', settings);
      console.log('🎫 Ticket:', ticketData.id);
      console.log('📱 Requester:', ticketData.requester);
      console.log('☎️ Teléfono ZAF:', ticketData.requester.phone || 'NO DISPONIBLE en ZAF');
      
      // Intentar obtener teléfono con REST API si ZAF no lo tiene
      if (!ticketData.requester.phone && ticketData.requester.id) {
        console.log('🔄 Intentando obtener teléfono con REST API...');
        const phone = await getRequesterPhone(ticketData.requester.id);
        if (phone) {
          console.log('✅ Teléfono obtenido exitosamente:', phone);
        }
      }
      
      updateUI();
      validateAll();
      loadHistory();
      
      // Escuchar cambios
      client.on('ticket.tags.changed', handleTagsChange);
      client.on('ticket.requester.id.changed', handleRequesterChange);
      
      console.log('✅ App inicializada correctamente');
      
    } catch (error) {
      console.error('❌ Error al inicializar:', error);
      notify('Error al inicializar la aplicación', 'error');
      
      // Mostrar en UI que hay un error
      document.getElementById('phone').textContent = 'Error de inicialización';
      document.getElementById('phone').style.color = '#e74c3c';
    }
  }
  
  // Iniciar
  initialize();

  // ==================== EVENTOS ====================
  
  function handleTagsChange() {
    console.log('🏷️ Tags cambiados');
    Promise.all([
      client.get('ticket'),
      client.get('ticket.requester')
    ]).then(async function([ticketData_, requesterData]) {
      ticketData = ticketData_.ticket;
      ticketData.requester = requesterData['ticket.requester'];
      
      // Intentar obtener teléfono con REST API si ZAF no lo tiene
      if (!ticketData.requester.phone && ticketData.requester.id) {
        console.log('🔄 Tags cambiaron, intentando obtener teléfono con REST API...');
        await getRequesterPhone(ticketData.requester.id);
      }
      
      validateAll();
      
      if (settings.enable_auto_send && allValid()) {
        console.log('🚀 Enviando automáticamente...');
        sendWhatsApp(true);
      }
    });
  }

  function handleRequesterChange() {
    console.log('👤 Requester cambiado');
    client.get('ticket.requester').then(async function(data) {
      ticketData.requester = data['ticket.requester'];
      console.log('📱 Nuevo requester:', ticketData.requester);
      
      // Intentar obtener teléfono con REST API si ZAF no lo tiene
      if (!ticketData.requester.phone && ticketData.requester.id) {
        console.log('🔄 Requester cambió, intentando obtener teléfono con REST API...');
        await getRequesterPhone(ticketData.requester.id);
      }
      
      updateUI();
      validateAll();
    });
  }

  // ==================== VALIDACIÓN ====================
  
  function validateAll() {
    const phone = getPhone();
    const tags = ticketData.tags || [];
    const targetTag = settings.target_tag || 'no_contesto_whatsapp';
    
    // Validar tag
    validation.tag = tags.some(t => t.toLowerCase() === targetTag.toLowerCase());
    
    // Validar teléfono
    validation.phone = phone !== null;
    
    // Validar país
    if (phone) {
      const normalized = normalizePhone(phone);
      const countryCode = detectCountry(normalized);
      validation.country = COUNTRIES.hasOwnProperty(countryCode);
    } else {
      validation.country = false;
    }
    
    updateValidationUI();
    updateAutoStatus();
    updateButton();
    
    console.log('✓ Validación:', validation);
  }

  function allValid() {
    return validation.tag && validation.phone && validation.country;
  }

  function updateValidationUI() {
    document.getElementById('check-tag').textContent = validation.tag ? '✓' : '✗';
    document.getElementById('check-tag').className = 'check ' + (validation.tag ? 'pass' : 'fail');
    
    document.getElementById('check-phone').textContent = validation.phone ? '✓' : '✗';
    document.getElementById('check-phone').className = 'check ' + (validation.phone ? 'pass' : 'fail');
    
    document.getElementById('check-country').textContent = validation.country ? '✓' : '✗';
    document.getElementById('check-country').className = 'check ' + (validation.country ? 'pass' : 'fail');
  }

  function updateAutoStatus() {
    const statusEl = document.getElementById('auto-status');
    if (allValid()) {
      statusEl.textContent = '✓ Listo para enviar';
      statusEl.className = 'ready';
    } else {
      statusEl.textContent = 'Esperando condiciones...';
      statusEl.className = '';
    }
  }

  function updateButton() {
    document.getElementById('manual-btn').disabled = !allValid();
  }

  // ==================== TELÉFONO ====================
  
  /**
   * Obtiene el teléfono del requester usando ZAF API primero,
   * y REST API como fallback si ZAF no devuelve el phone
   */
  async function getRequesterPhone(requesterId) {
    try {
      // Opción 1: Intentar con ZAF API primero (más rápido)
      if (ticketData.requester && ticketData.requester.phone) {
        console.log('✓ Teléfono obtenido de ZAF API:', ticketData.requester.phone);
        return ticketData.requester.phone;
      }
      
      // Opción 2: Fallback a REST API si ZAF no tiene el phone
      console.log('⚠️ ZAF API no devolvió phone, usando REST API como fallback...');
      
      const response = await client.request({
        url: `/api/v2/users/${requesterId}.json`,
        type: 'GET'
      });
      
      const phone = response.user?.phone || null;
      
      if (phone) {
        console.log('✓ Teléfono obtenido de REST API:', phone);
        // Actualizar ticketData con el phone obtenido
        if (ticketData.requester) {
          ticketData.requester.phone = phone;
        }
      } else {
        console.log('❌ No se encontró teléfono ni en ZAF ni en REST API');
      }
      
      return phone;
      
    } catch (error) {
      console.error('❌ Error obteniendo teléfono:', error);
      return null;
    }
  }
  
  function getPhone() {
    if (ticketData.requester && ticketData.requester.phone) {
      return ticketData.requester.phone;
    }
    return null;
  }

  function normalizePhone(phone) {
    if (!phone) return null;
    
    phone = phone.trim();
    
    // Remover caracteres no numéricos
    let cleaned = phone.replace(/[^0-9]/g, '');
    
    // Remover 00 inicial
    if (cleaned.startsWith('00')) {
      cleaned = cleaned.substring(2);
    }
    
    // Detectar país por código o longitud
    if (cleaned.startsWith('593')) return cleaned;  // Ecuador
    if (cleaned.startsWith('506')) return cleaned;  // Costa Rica
    if (cleaned.startsWith('52')) return cleaned;   // México
    
    // Por longitud
    if (cleaned.length === 9) return '593' + cleaned;  // Ecuador
    if (cleaned.length === 8) return '506' + cleaned;  // Costa Rica
    if (cleaned.length === 10) return '52' + cleaned;  // México
    
    return cleaned;
  }

  function detectCountry(phone) {
    if (!phone) return null;
    
    for (const code of Object.keys(COUNTRIES)) {
      if (phone.startsWith(code)) {
        return code;
      }
    }
    return null;
  }

  // ==================== UI ====================
  
  function updateUI() {
    const phone = getPhone();
    
    // Teléfono
    if (phone) {
      const normalized = normalizePhone(phone);
      const countryCode = detectCountry(normalized);
      if (countryCode && COUNTRIES[countryCode]) {
        document.getElementById('phone').textContent = 
          `+${normalized} ${COUNTRIES[countryCode].flag}`;
      } else {
        document.getElementById('phone').textContent = phone;
      }
    } else {
      document.getElementById('phone').textContent = 'No disponible';
    }
    
    // País
    if (phone) {
      const normalized = normalizePhone(phone);
      const countryCode = detectCountry(normalized);
      if (countryCode && COUNTRIES[countryCode]) {
        const country = COUNTRIES[countryCode];
        document.getElementById('country').textContent = 
          `${country.flag} ${country.name}`;
      } else {
        document.getElementById('country').textContent = '❌ No soportado';
      }
    } else {
      document.getElementById('country').textContent = '-';
    }
    
    // Estado
    document.getElementById('status').textContent = ticketData.status || '-';
  }

  // ==================== ENVIAR WHATSAPP ====================
  
  function sendWhatsApp(isAuto = false) {
    const phone = getPhone();
    if (!phone) {
      notify('No hay teléfono', 'error');
      return;
    }
    
    const normalized = normalizePhone(phone);
    const countryCode = detectCountry(normalized);
    
    if (!countryCode || !COUNTRIES[countryCode]) {
      notify('País no soportado', 'error');
      return;
    }
    
    console.log('📤 Enviando WhatsApp:', {
      phone: normalized,
      country: COUNTRIES[countryCode].name,
      auto: isAuto
    });
    
    // Construir plantilla según documento
    const plantilla = {
      destination: {
        integrationId: "--integrationId--",
        destinationId: normalized
      },
      author: {
        role: "appMaker"
      },
      messageSchema: "whatsapp",
      message: {
        type: "template",
        template: {
          namespace: "--namespace--",
          name: settings.nombre_plantilla,
          language: {
            policy: "deterministic",
            code: "es"
          }
        }
      }
    };
    
    // Construir body según documento
    const body = new URLSearchParams({
      subdominio: settings.subdominio,
      plantilla: JSON.stringify(plantilla),
      producto_id: settings.producto_id,
      telefono: normalized,
      nombre_plantilla: settings.nombre_plantilla
    });
    
    console.log('📡 Request a CXConnect:', {
      url: settings.cxconnect_api_url,
      subdominio: settings.subdominio,
      producto_id: settings.producto_id,
      telefono: normalized,
      nombre_plantilla: settings.nombre_plantilla
    });
    
    // Enviar
    client.request({
      url: settings.cxconnect_api_url,
      type: 'POST',
      contentType: 'application/x-www-form-urlencoded',
      data: body.toString(),
      secure: false
    }).then(function(response) {
      console.log('✅ Enviado:', response);
      
      addToHistory({
        time: new Date().toISOString(),
        phone: normalized,
        country: COUNTRIES[countryCode].name,
        status: 'success',
        auto: isAuto
      });
      
      notify('✅ WhatsApp enviado', 'success');
      
    }).catch(function(error) {
      console.error('❌ Error:', error);
      
      addToHistory({
        time: new Date().toISOString(),
        phone: normalized,
        country: COUNTRIES[countryCode].name,
        status: 'error',
        auto: isAuto,
        error: error.responseText || error.statusText
      });
      
      notify('❌ Error al enviar', 'error');
    });
  }

  // ==================== HISTORIAL ====================
  
  function loadHistory() {
    const history = getHistory();
    renderHistory(history);
  }

  function addToHistory(item) {
    const history = getHistory();
    history.unshift(item);
    
    // Mantener últimos 5
    if (history.length > 5) {
      history.length = 5;
    }
    
    saveHistory(history);
    renderHistory(history);
    logToTicket(item);
  }

  function getHistory() {
    try {
      const stored = localStorage.getItem(`whatsapp_${ticketData.id}`);
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      return [];
    }
  }

  function saveHistory(history) {
    try {
      localStorage.setItem(`whatsapp_${ticketData.id}`, JSON.stringify(history));
    } catch (e) {
      console.warn('No se pudo guardar historial');
    }
  }

  function renderHistory(history) {
    const container = document.getElementById('history');
    
    if (history.length === 0) {
      container.innerHTML = '<div class="empty-history">No hay mensajes</div>';
      return;
    }
    
    container.innerHTML = history.map(item => {
      const date = new Date(item.time).toLocaleString('es-MX', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
      
      const type = item.auto ? '🤖 Auto' : '👤 Manual';
      const status = item.status === 'success' ? '✅' : '❌';
      
      return `
        <div class="history-item ${item.status === 'error' ? 'error' : ''}">
          <div class="history-time">${date} - ${type}</div>
          <div class="history-details">${status} ${item.country} - +${item.phone}</div>
        </div>
      `;
    }).join('');
  }

  function logToTicket(item) {
    const text = `[WhatsApp UDLA] ${item.auto ? 'Automático' : 'Manual'}\n` +
      `📱 Teléfono: +${item.phone}\n` +
      `🌎 País: ${item.country}\n` +
      `${item.status === 'success' ? '✅' : '❌'} Estado: ${item.status}\n` +
      `🕐 ${new Date(item.time).toLocaleString('es-MX')}`;
    
    client.request({
      url: `/api/v2/tickets/${ticketData.id}.json`,
      type: 'PUT',
      contentType: 'application/json',
      data: JSON.stringify({
        ticket: {
          comment: {
            body: text,
            public: false
          }
        }
      })
    }).catch(function(error) {
      console.warn('No se pudo registrar log');
    });
  }

  // ==================== NOTIFICACIONES ====================
  
  function notify(message, type) {
    const notif = document.getElementById('notification');
    notif.textContent = message;
    notif.className = `notification ${type}`;
    
    setTimeout(() => {
      notif.classList.add('hidden');
    }, 4000);
  }

  // ==================== BOTÓN MANUAL ====================
  
  document.getElementById('manual-btn').addEventListener('click', function() {
    console.log('👆 Envío manual');
    sendWhatsApp(false);
  });

  // ==================== BOTÓN DEBUG ====================
  
  document.getElementById('debug-btn').addEventListener('click', function() {
    const debugDiv = document.getElementById('debug-info');
    
    if (debugDiv.classList.contains('hidden')) {
      // Mostrar debug info
      const debugInfo = {
        'ZAF Inicializado': client ? 'Sí' : 'No',
        'Ticket ID': ticketData.id || 'N/A',
        'Ticket Status': ticketData.status || 'N/A',
        'Ticket Tags': ticketData.tags || [],
        'Requester ID': ticketData.requester?.id || 'N/A',
        'Requester Name': ticketData.requester?.name || 'N/A',
        'Requester Email': ticketData.requester?.email || 'N/A',
        'Requester Phone': ticketData.requester?.phone || 'NO DISPONIBLE ❌',
        'Phone Normalized': getPhone() ? normalizePhone(getPhone()) : 'N/A',
        'Country Detected': getPhone() ? detectCountry(normalizePhone(getPhone())) : 'N/A',
        'Validations': validation,
        'Settings': {
          subdominio: settings.subdominio,
          producto_id: settings.producto_id,
          nombre_plantilla: settings.nombre_plantilla,
          target_tag: settings.target_tag,
          enable_auto_send: settings.enable_auto_send
        }
      };
      
      debugDiv.textContent = JSON.stringify(debugInfo, null, 2);
      debugDiv.classList.remove('hidden');
      this.textContent = '🔍 Ocultar Debug Info';
    } else {
      // Ocultar debug info
      debugDiv.classList.add('hidden');
      this.textContent = '🔍 Ver Debug Info';
    }
  });

  console.log('✅ App lista');

})();
