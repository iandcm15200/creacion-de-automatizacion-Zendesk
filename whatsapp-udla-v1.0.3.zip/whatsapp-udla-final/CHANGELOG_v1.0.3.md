# CHANGELOG - Versión 1.0.3

## 🐛 FIX CRÍTICO: Teléfono "No disponible"

### Problema Identificado
- **ZAF API** (`client.get('ticket.requester')`) no siempre devuelve el campo `phone`
- Esto causaba que la app mostrara "Teléfono: No disponible" aunque el usuario SÍ tuviera teléfono en Zendesk
- El script de Tampermonkey sí funcionaba porque usa **REST API**

### Solución Implementada
✅ **Función `getRequesterPhone()` con fallback a REST API**

```javascript
async function getRequesterPhone(requesterId) {
  // 1. Intentar con ZAF API primero (más rápido)
  if (ticketData.requester?.phone) {
    return ticketData.requester.phone;
  }
  
  // 2. Fallback a REST API si ZAF no tiene el phone
  const response = await client.request({
    url: `/api/v2/users/${requesterId}.json`,
    type: 'GET'
  });
  
  return response.user?.phone || null;
}
```

### Cambios Técnicos

#### 1. Nueva función `getRequesterPhone()`
- Usa ZAF API primero (más rápido)
- Si no obtiene phone, hace fallback a REST API
- Actualiza `ticketData.requester.phone` con el valor obtenido
- Logs detallados para debugging

#### 2. Modificado `initialize()`
```javascript
// Antes
ticketData.requester = requesterResponse['ticket.requester'];

// Ahora
ticketData.requester = requesterResponse['ticket.requester'];
if (!ticketData.requester.phone && ticketData.requester.id) {
  await getRequesterPhone(ticketData.requester.id);
}
```

#### 3. Modificado `handleRequesterChange()`
```javascript
// Ahora es async y usa getRequesterPhone
async function(data) {
  ticketData.requester = data['ticket.requester'];
  if (!ticketData.requester.phone && ticketData.requester.id) {
    await getRequesterPhone(ticketData.requester.id);
  }
  updateUI();
  validateAll();
}
```

#### 4. Modificado `handleTagsChange()`
```javascript
// Ahora es async y usa getRequesterPhone
async function([ticketData_, requesterData]) {
  ticketData = ticketData_.ticket;
  ticketData.requester = requesterData['ticket.requester'];
  if (!ticketData.requester.phone && ticketData.requester.id) {
    await getRequesterPhone(ticketData.requester.id);
  }
  validateAll();
  // ...
}
```

### Resultado Esperado

**ANTES (v1.0.2):**
```
Teléfono: No disponible ❌
País: -
Validaciones:
  ✗ Teléfono válido
  ✗ País soportado
```

**AHORA (v1.0.3):**
```
Teléfono: +593939485375 🇪🇨
País: 🇪🇨 Ecuador
Validaciones:
  ✓ Etiqueta: no_contesto_whatsapp
  ✓ Teléfono válido
  ✓ País soportado
```

### Logs de Debug

La app ahora muestra en consola:

```
☎️ Teléfono ZAF: NO DISPONIBLE en ZAF
🔄 Intentando obtener teléfono con REST API...
⚠️ ZAF API no devolvió phone, usando REST API como fallback...
✓ Teléfono obtenido de REST API: +593939485375
✅ Teléfono obtenido exitosamente: +593939485375
```

### Testing

1. **Caso de prueba:**
   - Usuario: María Vélez Sánchez (ID: 41041223924244)
   - Teléfono en Zendesk: +593939485375
   - ZAF API: NO devuelve phone
   - REST API: ✅ Devuelve phone

2. **Resultado esperado:**
   - App detecta que ZAF no tiene phone
   - Hace fallback a REST API
   - Obtiene +593939485375
   - Muestra correctamente en UI
   - Permite enviar WhatsApp

### Compatibilidad

- ✅ Compatible con versiones anteriores
- ✅ No requiere cambios en configuración
- ✅ Funciona con ZAF SDK 2.0
- ✅ Funciona con todos los países soportados (MX, EC, CR)

### Próximos Pasos

1. Desinstalar app v1.0.2
2. Instalar app v1.0.3
3. Probar con ticket #47918 (María Vélez Sánchez)
4. Verificar que se muestra el teléfono correctamente
5. Aplicar Macro 007 y verificar envío automático

---

**Versión:** 1.0.3  
**Fecha:** 2025-12-06  
**Fix:** ZAF API phone fallback to REST API  
**Autor:** APLATAM
